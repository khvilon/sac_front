$(function(){

	alert(1);
});